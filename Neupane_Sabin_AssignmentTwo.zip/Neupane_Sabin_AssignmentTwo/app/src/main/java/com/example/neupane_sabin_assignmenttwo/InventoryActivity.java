package com.example.neupane_sabin_assignmenttwo;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.List;

// Activity for managing inventory items and sending SMS alerts for low stock
public class InventoryActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 101; // Code used to identify SMS permission request
    private EditText editItemName, editItemQty; // Input fields for item name and quantity
    private DatabaseHelper dbHelper;            // SQLite database helper instance
    private InventoryAdapter adapter;           // Adapter to populate the ListView with items

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        checkSmsPermission(); // Ensure the app has SMS permission

        // Initialize input fields and button
        editItemName = findViewById(R.id.editItemName);
        editItemQty = findViewById(R.id.editItemQty);
        Button btnAddItem = findViewById(R.id.btnAddItem);
        ListView listInventory = findViewById(R.id.listInventory);

        // Initialize database helper and load data
        dbHelper = new DatabaseHelper(this);
        loadInventoryData();

        // Handle add item button click
        btnAddItem.setOnClickListener(v -> addItem());
    }

    // Load inventory items from the database and display them using the adapter
    private void loadInventoryData() {
        List<Item> items = dbHelper.getAllItems(); // Get all items from DB
        ListView listInventory = findViewById(R.id.listInventory);
        adapter = new InventoryAdapter(this, items, dbHelper, this::loadInventoryData); // Provide refresh callback
        listInventory.setAdapter(adapter);
    }

    // Adds a new item to the database and sends an SMS if quantity is low
    private void addItem() {
        String name = editItemName.getText().toString().trim();
        String qtyStr = editItemQty.getText().toString().trim();

        // Validate inputs
        if (name.isEmpty() || qtyStr.isEmpty()) {
            Toast.makeText(this, "Please enter name and quantity", Toast.LENGTH_SHORT).show();
            return;
        }

        int quantity = Integer.parseInt(qtyStr);

        // Insert item into database
        if (dbHelper.insertItem(name, quantity)) {
            Toast.makeText(this, "Item added!", Toast.LENGTH_SHORT).show();
            editItemName.setText("");
            editItemQty.setText("");
            loadInventoryData();

            // Send SMS alert if quantity is low
            if (quantity < 5) {
                sendLowInventoryAlert(name, quantity);
            }
        } else {
            Toast.makeText(this, "Item with this name already exists.", Toast.LENGTH_SHORT).show();
        }
    }

    // Requests SMS permission from the user if not already granted
    private void checkSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        }
    }

    // Handles the result of the SMS permission request
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS Permission Granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS Permission Denied. Alerts will not be sent.", Toast.LENGTH_LONG).show();
            }
        }
    }

    // Sends an SMS alert when the inventory for an item is low
    private void sendLowInventoryAlert(String itemName, int quantity) {
        // Ensure permission is granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            try {
                String phoneNumber = "5551234567"; // Placeholder phone number
                String message = "Low inventory alert: " + itemName + " has only " + quantity + " items left.";

                // Send SMS using SmsManager
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(phoneNumber, null, message, null, null);

                Toast.makeText(this, "Low inventory SMS sent.", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "SMS failed to send.", Toast.LENGTH_SHORT).show();
                e.printStackTrace();
            }
        } else {
            Log.d("InventoryActivity", "SMS permission not granted. Cannot send alert.");
        }
    }
}
