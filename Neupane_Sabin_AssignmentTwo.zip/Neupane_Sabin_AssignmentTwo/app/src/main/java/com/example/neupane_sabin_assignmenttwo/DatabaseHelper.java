package com.example.neupane_sabin_assignmenttwo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

// Helper class to manage SQLite database for user login and inventory tracking
public class DatabaseHelper extends SQLiteOpenHelper {

    // Database and table configuration
    private static final String DATABASE_NAME = "InventoryApp.db";
    private static final int DATABASE_VERSION = 7; // Version used for upgrades

    // User table and columns
    private static final String TABLE_USERS = "users";
    private static final String COL_USERNAME = "username";
    private static final String COL_PASSWORD = "password";

    // Inventory table and columns
    private static final String TABLE_INVENTORY = "inventory";
    private static final String COL_ID = "id";
    private static final String COL_NAME = "name";
    private static final String COL_QTY = "quantity";

    // Constructor to initialize the database helper
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Called when the database is created for the first time
    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create users table
        String CREATE_USERS_TABLE = "CREATE TABLE " + TABLE_USERS + "("
                + COL_USERNAME + " TEXT PRIMARY KEY,"
                + COL_PASSWORD + " TEXT)";
        db.execSQL(CREATE_USERS_TABLE);

        // Create inventory table
        String CREATE_INVENTORY_TABLE = "CREATE TABLE " + TABLE_INVENTORY + "("
                + COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COL_NAME + " TEXT UNIQUE,"
                + COL_QTY + " INTEGER)";
        db.execSQL(CREATE_INVENTORY_TABLE);
    }

    // Called when the database needs to be upgraded
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop existing tables and recreate them
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_INVENTORY);
        onCreate(db);
    }

    // Add a new user to the users table
    public boolean addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, username);
        values.put(COL_PASSWORD, password);
        long result = db.insert(TABLE_USERS, null, values);
        return result != -1; // Returns true if insertion was successful
    }

    // Check if user credentials are valid
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_USERS
                        + " WHERE " + COL_USERNAME + " = ? AND " + COL_PASSWORD + " = ?",
                new String[]{username, password});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    // Check if a user with the given username already exists
    public boolean checkUserExists(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_USERS
                        + " WHERE " + COL_USERNAME + " = ?",
                new String[]{username});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    // Insert a new inventory item if it doesn't already exist
    public boolean insertItem(String name, int quantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_NAME, name);
        values.put(COL_QTY, quantity);
        // CONFLICT_IGNORE prevents error if item already exists
        long result = db.insertWithOnConflict(TABLE_INVENTORY, null, values, SQLiteDatabase.CONFLICT_IGNORE);
        return result != -1;
    }

    // Retrieve all items from the inventory table
    public List<Item> getAllItems() {
        List<Item> items = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_INVENTORY, null);
        if (cursor.moveToFirst()) {
            do {
                String name = cursor.getString(cursor.getColumnIndexOrThrow(COL_NAME));
                int qty = cursor.getInt(cursor.getColumnIndexOrThrow(COL_QTY));
                items.add(new Item(name, qty));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return items;
    }

    // Update the quantity of a specific inventory item
    public boolean updateItemQuantity(String name, int newQuantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_QTY, newQuantity);
        int result = db.update(TABLE_INVENTORY, values, COL_NAME + " = ?", new String[]{name});
        return result > 0;
    }

    // Delete an inventory item by name
    public boolean deleteItemByName(String name) {
        SQLiteDatabase db = this.getWritableDatabase();
        int result = db.delete(TABLE_INVENTORY, COL_NAME + " = ?", new String[]{name});
        return result > 0;
    }
}