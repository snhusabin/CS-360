// Adapter class for binding inventory items to a ListView and handling update/delete actions
package com.example.neupane_sabin_assignmenttwo;

import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import java.util.List;

public class InventoryAdapter extends ArrayAdapter<Item> {
    private final Context context;
    private final DatabaseHelper dbHelper;
    private final Runnable refreshCallback;

    // Constructor to initialize the adapter with context, item list, database helper, and refresh callback
    public InventoryAdapter(Context context, List<Item> items, DatabaseHelper dbHelper, Runnable refreshCallback) {
        super(context, R.layout.item_inventory_row, items);
        this.context = context;
        this.dbHelper = dbHelper;
        this.refreshCallback = refreshCallback;
    }

    // Provides the view for each item in the ListView
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Item currentItem = getItem(position);
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.item_inventory_row, parent, false);
        }

        TextView textItem = convertView.findViewById(R.id.textItemName);
        Button btnDelete = convertView.findViewById(R.id.btnDelete);
        Button btnUpdate = convertView.findViewById(R.id.btnUpdate);

        textItem.setText(String.format("%s (Qty: %d)", currentItem.getName(), currentItem.getQuantity()));

        // Handle delete button click: deletes the item and refreshes the list
        btnDelete.setOnClickListener(v -> {
            dbHelper.deleteItemByName(currentItem.getName());
            Toast.makeText(context, "Deleted " + currentItem.getName(), Toast.LENGTH_SHORT).show();
            refreshCallback.run();
        });

        // Handle update button click: shows dialog to update quantity
        btnUpdate.setOnClickListener(v -> showUpdateDialog(currentItem));

        return convertView;
    }

    // Displays a dialog to update the quantity of a selected item
    private void showUpdateDialog(Item item) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Update Quantity for " + item.getName());

        final EditText input = new EditText(context);
        input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        input.setHint("Enter new quantity");
        builder.setView(input);

        // On positive button click, update the item quantity in database
        builder.setPositiveButton("Update", (dialog, which) -> {
            String newQtyStr = input.getText().toString().trim();
            if (!newQtyStr.isEmpty()) {
                int newQty = Integer.parseInt(newQtyStr);
                if (dbHelper.updateItemQuantity(item.getName(), newQty)) {
                    Toast.makeText(context, "Quantity updated!", Toast.LENGTH_SHORT).show();
                    refreshCallback.run();
                } else {
                    Toast.makeText(context, "Update failed.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // On negative button click, close the dialog
        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());

        builder.show();
    }
}