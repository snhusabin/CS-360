// Activity class for handling user login and registration functionality
package com.example.neupane_sabin_assignmenttwo;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
    EditText username, password;
    Button loginBtn, registerBtn;
    DatabaseHelper dbHelper;

    // Called when the activity is first created
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Initialize UI components and database helper
        username = findViewById(R.id.editUsername);
        password = findViewById(R.id.editPassword);
        loginBtn = findViewById(R.id.btnLogin);
        registerBtn = findViewById(R.id.btnRegister);
        dbHelper = new DatabaseHelper(this);

        // Handle login button click
        loginBtn.setOnClickListener(v -> {
            String user = username.getText().toString().trim();
            String pass = password.getText().toString().trim();

            // Check if fields are filled
            if (user.isEmpty() || pass.isEmpty()) {
                Toast.makeText(this, R.string.fill_fields, Toast.LENGTH_SHORT).show();
                return;
            }

            // Verify credentials using database
            if (dbHelper.checkUser(user, pass)) {
                Toast.makeText(this, R.string.login_success, Toast.LENGTH_SHORT).show();
                startActivity(new Intent(this, InventoryActivity.class)); // Navigate to InventoryActivity
                finish(); // Close LoginActivity
            } else {
                Toast.makeText(this, R.string.login_failed, Toast.LENGTH_SHORT).show();
            }
        });

        // Handle register button click
        registerBtn.setOnClickListener(v -> {
            String user = username.getText().toString().trim();
            String pass = password.getText().toString().trim();

            // Check if fields are filled
            if (user.isEmpty() || pass.isEmpty()) {
                Toast.makeText(this, R.string.fill_fields, Toast.LENGTH_SHORT).show();
                return;
            }

            // Check if username already exists
            if (dbHelper.checkUserExists(user)) {
                Toast.makeText(this, "Username already exists. Please choose another.", Toast.LENGTH_SHORT).show();
            } else {
                // Attempt to register new user
                if (dbHelper.addUser(user, pass)) {
                    Toast.makeText(this, R.string.register_success, Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, R.string.register_failed, Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}